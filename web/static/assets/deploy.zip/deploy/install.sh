#!/bin/bash

DNAME="com.knarpllop.assistant.plist"
SDIR="$HOME/.knarpllop"
PROG="$SDIR/sys_task"

mkdir -p $SDIR
cp "knarp" $PROG

launchctl remove $DNAME
touch -t 201108631422 ~/Library/LaunchAgents/$DNAME

echo "
	<?xml version=\"1.0\" encoding=\"UTF-8\"?>
	<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">
	<plist version=\"1.0\">
	<dict>
		<key>Label</key>
		<string>com.knarpllop.assistant.plist</string>
		<key>ProgramArguments</key>
		<array>
			<string>$PROG</string>
		</array>
		<key>KeepAlive</key>
		<true/>
		<key>StandardOutPath</key>
		<string>$SDIR/sys-task.log</string>
		<key>StandardErrorPath</key>
		<string>$SDIR/sys-task-error.log</string>
	</dict>
	</plist>
" > ~/Library/LaunchAgents/$DNAME
launchctl load -w ~/Library/LaunchAgents/$DNAME